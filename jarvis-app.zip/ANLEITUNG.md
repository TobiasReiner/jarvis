# JARVIS als echte App aufs Handy – in 10 Minuten

Diese Version läuft **komplett unabhängig von claude.ai** – als installierbare
Web-App (PWA) mit eigenem Icon, Vollbild, Sprachein- und -ausgabe und
optional ElevenLabs-Premium-Stimme.

## Was du brauchst
1. **Kostenloses GitHub-Konto** → github.com
2. **Claude API-Key** (das Gehirn): console.anthropic.com → API Keys →
   „Create Key" → Key kopieren (beginnt mit `sk-ant-…`).
   Hinweis: Die API wird pro Nutzung abgerechnet (Guthaben aufladen,
   5–10 € reichen lange für den Privatgebrauch).
3. Optional: **ElevenLabs-Konto** für die Premium-Stimme
   (elevenlabs.io → Profil → API Key; Voice-ID unter „Voices").

## Schritt 1 – Hochladen (GitHub Pages, gratis)
1. Auf github.com einloggen → oben rechts **+** → **New repository**
2. Name z. B. `jarvis` → **Public** → „Create repository"
3. **„uploading an existing file"** anklicken → alle 5 Dateien aus diesem
   ZIP hineinziehen (`index.html`, `manifest.json`, `sw.js`,
   `icon-192.png`, `icon-512.png`) → **Commit changes**
4. Im Repository: **Settings → Pages** → unter „Branch" **main** wählen
   → **Save**
5. Nach 1–2 Minuten erscheint oben deine Adresse:
   `https://DEINNAME.github.io/jarvis/`

## Schritt 2 – Als App installieren
**iPhone:** Adresse in **Safari** öffnen → Teilen-Symbol →
**„Zum Home-Bildschirm"** → JARVIS-Icon erscheint, startet im Vollbild.

**Android:** Adresse in **Chrome** öffnen → Menü (⋮) →
**„App installieren"** / „Zum Startbildschirm hinzufügen".

**Desktop:** In Chrome/Edge erscheint rechts in der Adressleiste ein
Installations-Symbol.

## Schritt 3 – Einrichten (einmalig)
1. JARVIS öffnen → **Zahnrad** oben rechts
2. **Claude API-Key** einfügen → Häkchen bei „Schlüssel merken"
3. Optional: Engine auf **ElevenLabs** stellen, Key + Voice-ID einfügen
4. **Stimmtest** drücken (schaltet auch das Audio frei)

## Wenn die Stimme stumm bleibt
- **iPhone: Stummschalter!** Die Sprachausgabe respektiert den
  Klingel-/Stumm-Schalter an der Seite. Auf laut stellen, Lautstärke hoch.
- Erst **einmal irgendwo tippen** – Browser geben Audio erst nach der
  ersten Berührung frei (JARVIS zeigt das auch an).
- Zahnrad → **Diagnose-Zeile** prüfen: Steht dort „Stimmen installiert: 0",
  einmal Stimmtest drücken; bleibt es 0, System-TTS im Browser nicht
  verfügbar → ElevenLabs verwenden.
- Bessere Stimmen am iPhone: Einstellungen → Bedienungshilfen →
  Gesprochene Inhalte → Stimmen → Deutsch → z. B. Siri-Stimme laden.
- **Mikrofon**: funktioniert in Safari (iPhone) bzw. Chrome (Android),
  nicht in In-App-Browsern. Beim ersten Mal Mikrofon-Zugriff erlauben.

## Sicherheit
- Deine Keys bleiben **nur auf deinem Gerät** (lokaler Speicher,
  abwählbar) und werden ausschließlich direkt an Anthropic bzw.
  ElevenLabs gesendet.
- Repository ist öffentlich, enthält aber **keine** Keys – nur den Code.

Viel Spaß, Master. 🟣
